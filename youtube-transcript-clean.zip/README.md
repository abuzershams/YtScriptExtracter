Run with Python:
pip install -r requirements.txt
python app.py
Open http://localhost:5000
The app returns transcript text without timestamps and cleans common caption overlaps/repetitions.
