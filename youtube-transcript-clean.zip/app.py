from flask import Flask, request, jsonify, render_template
from youtube_transcript_api import YouTubeTranscriptApi
import re

app = Flask(__name__)

def video_id(url):
    m = re.search(r'(?:v=|youtu\.be/|/shorts/|/embed/)([A-Za-z0-9_-]{11})', url)
    return m.group(1) if m else None

def clean_segments(items):
    # Remove exact repeated consecutive captions and overlapping caption tails.
    texts = []
    for x in items:
        t = getattr(x, "text", None)
        if t is None and isinstance(x, dict):
            t = x.get("text", "")
        t = re.sub(r'\s+', ' ', (t or '')).strip()
        if not t: continue
        if texts and t == texts[-1]: continue

        # If the new caption begins with the end of the previous caption,
        # remove the repeated overlap.
        if texts:
            prev = texts[-1]
            pw, nw = prev.split(), t.split()
            best = 0
            maxk = min(len(pw), len(nw), 30)
            for k in range(maxk, 0, -1):
                if [w.lower() for w in pw[-k:]] == [w.lower() for w in nw[:k]]:
                    best = k; break
            if best:
                t = ' '.join(nw[best:]).strip()
                if not t: continue
        texts.append(t)

    # A second pass for repeated words/short phrases caused by caption rollbacks.
    out = []
    for t in texts:
        if not out:
            out.append(t); continue
        prev = out[-1]
        # repeated suffix/prefix up to 8 words
        pw, tw = prev.split(), t.split()
        maxk = min(8, len(pw), len(tw))
        cut = 0
        for k in range(maxk, 0, -1):
            if [w.lower().strip(".,!?।") for w in pw[-k:]] == [w.lower().strip(".,!?।") for w in tw[:k]]:
                cut = k; break
        if cut:
            t = ' '.join(tw[cut:]).strip()
        if t and t.lower() != prev.lower():
            out.append(t)

    # Remove obvious immediate repeated words (Hindi/English).
    result = []
    for t in out:
        words = t.split()
        compact = []
        for w in words:
            if compact and re.sub(r'[^\w\u0900-\u097F]', '', w).lower() == re.sub(r'[^\w\u0900-\u097F]', '', compact[-1]).lower():
                continue
            compact.append(w)
        if compact: result.append(' '.join(compact))
    return '\n'.join(result)

@app.get("/")
def home(): return render_template("index.html")

@app.post("/api/transcript")
def transcript():
    data = request.get_json(silent=True) or {}
    vid = video_id((data.get("url") or "").strip())
    if not vid: return jsonify(error="Invalid YouTube URL."), 400
    try:
        api = YouTubeTranscriptApi()
        items = api.fetch(vid)
        return jsonify(transcript=clean_segments(items))
    except Exception:
        return jsonify(error="Transcript unavailable. The video may have captions disabled or be restricted."), 404

app.run(host="0.0.0.0", port=5000)
